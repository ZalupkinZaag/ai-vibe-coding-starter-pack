# Steam Market Sniper — v1.1

Полная инструкция с нуля — в `SETUP.md`. Быстрая настройка окном — `python setup_wizard.py`.

Асинхронный наблюдатель за ценами Steam Community Market с оповещениями в Telegram.

Важно: скрипт следит за **ценами конкретных предметов**, а не за списком продавцов. Публичный эндпоинт `market/priceoverview/` возвращает самую низкую цену (`lowest_price`), медиану (`median_price`) и объём (`volume`) по предмету. Список продавцов он не показывает.

## Установка

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # Windows: copy .env.example .env
# заполни TELEGRAM_BOT_TOKEN в .env
cp config.example.json config.json
# отредактируй config.json под свои предметы и пороги
```

Запуск:

```bash
# Linux/macOS
set -a && source .env && set +a
python -m src.main

# Windows PowerShell
$env:TELEGRAM_BOT_TOKEN = "ваш_токен"
python -m src.main
```

## Настройка

- `steam.country`, `steam.currency`, `steam.currency_id` — регион и валюта запроса. Для USD это `US`, `USD`, `1`.
- `request_delay_seconds` — пауза между запросами, защита от ограничения частоты.
- `timeout_seconds` — таймаут одного запроса.
- `telegram.chat_id` — чат, куда приходят оповещения.
- `watch[].appid` — идентификатор игры: 730 — CS2, 570 — Dota 2.
- `watch[].market_hash_name` — точное название предмета с рынка Steam. Проверяется в ссылке на лот; опечатка приведёт к пустому ответу.
- `watch[].interval_seconds` — как часто опрашивать предмет, от 30 до 86400 секунд.
- `watch[].rules` — правила `below` (цена ниже порога), `drop_pct` (падение на N% от предыдущего наблюдения), `rise_pct` (рост на N%).
- `alert_cooldown_seconds` — минимальный интервал между повторными алертами по одному правилу.

Токен Telegram хранится только в переменной окружения `TELEGRAM_BOT_TOKEN`, не в конфиге.

## Что делает скрипт

1. Опрашивает каждый предмет по его расписанию.
2. Проверяет ответ Steam: HTTP-статус, отсутствие HTML, `success=true`, корректность цен и объёма.
3. Записывает наблюдение в SQLite (`history.db`).
4. Сравнивает с предыдущим значением и проверяет правила.
5. Отправляет оповещение в Telegram с соблюдением cooldown.
6. При HTTP 429 и 5xx повторяет запрос не более трёх раз с задержкой.

## Бесплатный запуск через GitHub Actions

В наборе есть готовый workflow `.github/workflows/snipe.yml`: он запускает проверку каждые 5 минут и по событию `workflow_dispatch`. Для него добавлен режим одного прохода:

```bash
python -m src.main --once
```

Порядок: создай приватный репозиторий, загрузи туда содержимое `product/`, в Settings → Secrets and variables → Actions добавь `TELEGRAM_BOT_TOKEN` и `TELEGRAM_CHAT_ID`. Workflow сам соберёт `config.json` из `config.actions.json`. В Actions конфиге используй только правило `below`: история цен в SQLite на ephemeral-раннере не сохраняется, поэтому `drop_pct` и `rise_pct` там не работают.

Ограничение бесплатных минут: для публичного репозитория их лимит 2000 минут в месяц; проверка раз в 5 минут укладывается в него.

## Ограничения

Публичный эндпоинт может меняться и ограничивать частоту запросов. Скрипт не гарантирует прибыль от торговли и не работает с приватными данными аккаунта. Для непрерывного цикла с историей цен используй VPS и готовый systemd-юнит из `systemd/`.

## Проверка

```bash
python -m pytest -q
```

Тесты покрывают разбор локализованных цен и объёмов, валидацию ответа Steam, все три типа правил, cooldown, конфигурацию, SQLite и повторные запросы.
