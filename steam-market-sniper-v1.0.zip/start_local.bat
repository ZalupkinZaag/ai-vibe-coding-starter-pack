@echo off
cd /d "%~dp0"
echo Starting Telegram bot and price watcher in separate windows...
start "Steam Sniper Bot" cmd /k python -m src.bot
start "Steam Sniper Watch" cmd /k python -m src.main
echo Both processes started. Close their windows to stop.
