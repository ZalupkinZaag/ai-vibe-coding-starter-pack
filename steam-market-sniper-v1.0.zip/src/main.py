"""Entry point for the Steam market sniper."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
from pathlib import Path

import httpx

from .alerts import send_alert
from .client import SteamClient
from .core import validate_config
from .storage import Storage
from .watcher import run

logger = logging.getLogger("steam_sniper")


def load_config(path: str) -> dict:
    with Path(path).open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    return validate_config(raw)


async def amain(config_path: str, db_path: str, token: str) -> None:
    config = load_config(config_path)
    storage = Storage(db_path)
    stop_event = asyncio.Event()

    loop = asyncio.get_running_loop()
    try:
        loop.add_signal_handler(signal.SIGINT, stop_event.set)
        loop.add_signal_handler(signal.SIGTERM, stop_event.set)
    except (NotImplementedError, RuntimeError):
        pass

    async with httpx.AsyncClient() as http:
        client = SteamClient(config["steam"], http)
        chat_id = config["telegram"]["chat_id"]

        async def send(text: str) -> None:
            await send_alert(http, token, chat_id, text)

        await run(config, client, storage, send, stop_event)


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("TELEGRAM_BOT_TOKEN is not set")
    config_path = os.environ.get("SNIPER_CONFIG", "config.json")
    db_path = os.environ.get("SNIPER_DB", "history.db")
    try:
        asyncio.run(amain(config_path, db_path, token))
    except KeyboardInterrupt:
        logger.info("stopped by user")


if __name__ == "__main__":
    raise SystemExit(main())
