"""Pure logic for the Steam market sniper. No I/O, safe to test in isolation."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

MAX_PRICE = Decimal("1000000000")
MAX_VOLUME = 1_000_000_000_000
MAX_TEXT = 4000
RULE_TYPES = {"below", "drop_pct", "rise_pct"}


@dataclass(frozen=True)
class Observation:
    appid: int
    market_hash_name: str
    lowest: Decimal
    median: Decimal | None
    volume: int | None
    currency: str
    observed_at: str


def parse_price(raw: Any) -> Decimal | None:
    """Parse a localized Steam price string. Returns None on invalid input."""
    if raw is None:
        return None
    if isinstance(raw, bool):
        return None
    if isinstance(raw, (int, float, Decimal)):
        try:
            value = Decimal(str(raw))
        except InvalidOperation:
            return None
        return value if value.is_finite() and Decimal(0) <= value <= MAX_PRICE else None
    if not isinstance(raw, str):
        return None

    text = raw.strip()
    if not text:
        return None
    if re.search(r"[eE]", text):
        return None
    cleaned = re.sub(r"[^\d.,-]", "", text)
    if not cleaned or cleaned in {"-", ".", ",", "-.", "-,"}:
        return None

    negative = cleaned.startswith("-")
    cleaned = cleaned.lstrip("-")

    if "," in cleaned and "." in cleaned:
        decimal_sep = "," if cleaned.rfind(",") > cleaned.rfind(".") else "."
        thousands_sep = "." if decimal_sep == "," else ","
        cleaned = cleaned.replace(thousands_sep, "").replace(decimal_sep, ".")
    elif "," in cleaned:
        parts = cleaned.split(",")
        if len(parts) > 2:
            cleaned = "".join(parts[:-1]) + "." + parts[-1]
        elif len(parts) == 2 and len(parts[1]) in (1, 2):
            cleaned = parts[0] + "." + parts[1]
        else:
            cleaned = "".join(parts)
    elif cleaned.count(".") > 1:
        parts = cleaned.split(".")
        cleaned = "".join(parts[:-1]) + "." + parts[-1]

    try:
        value = Decimal(cleaned)
    except InvalidOperation:
        return None
    if not value.is_finite() or value < 0 or value > MAX_PRICE:
        return None
    return -value if negative else value


def parse_volume(raw: Any) -> int | None:
    """Parse a volume string such as '1,234' or '12 345'."""
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw if 0 <= raw <= MAX_VOLUME else None
    if not isinstance(raw, str):
        return None
    digits = re.sub(r"\D", "", raw)
    if not digits:
        return None
    value = int(digits)
    return value if 0 <= value <= MAX_VOLUME else None


def parse_priceoverview(
    payload: Any,
    *,
    appid: int,
    market_hash_name: str,
    currency: str,
) -> Observation | None:
    """Validate and convert a priceoverview response. Invalid data returns None."""
    if not isinstance(payload, dict) or payload.get("success") is not True:
        return None
    lowest = parse_price(payload.get("lowest_price"))
    if lowest is None:
        return None
    raw_median = payload.get("median_price")
    if raw_median is not None:
        median = parse_price(raw_median)
        if median is None:
            return None
    else:
        median = None
    raw_volume = payload.get("volume")
    if raw_volume is not None:
        volume = parse_volume(raw_volume)
        if volume is None:
            return None
    else:
        volume = None
    return Observation(
        appid=appid,
        market_hash_name=market_hash_name,
        lowest=lowest,
        median=median,
        volume=volume,
        currency=currency,
        observed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )


def evaluate_rule(
    rule_type: str,
    value: float,
    current: Decimal,
    previous: Decimal | None,
) -> bool:
    """Evaluate one alert rule against the current and previous lowest price."""
    if rule_type not in RULE_TYPES:
        return False
    target = Decimal(str(value))
    if not target.is_finite() or target <= 0:
        return False
    if rule_type == "below":
        return current <= target
    if previous is None or previous <= 0:
        return False
    delta_pct = (previous - current) / previous * Decimal(100)
    if rule_type == "drop_pct":
        return delta_pct >= target
    return (current - previous) / previous * Decimal(100) >= target


def is_cooldown_over(last_alert_at: float | None, now: float, cooldown: float) -> bool:
    """Return True when enough time has passed since the last alert."""
    if cooldown <= 0:
        return True
    if last_alert_at is None:
        return True
    if now < last_alert_at:
        return True
    return now - last_alert_at >= cooldown


def build_alert_text(observation: Observation, rule_type: str, value: float) -> str:
    """Build a plain-text Telegram alert. Plain text avoids Markdown injection."""
    return (
        f"Steam Market alert\n"
        f"Item: {observation.market_hash_name}\n"
        f"AppID: {observation.appid}\n"
        f"Rule: {rule_type} {value}\n"
        f"Lowest: {observation.lowest} {observation.currency}\n"
        f"Median: {observation.median or 'n/a'} {observation.currency}\n"
        f"Volume: {observation.volume if observation.volume is not None else 'n/a'}\n"
        f"Time: {observation.observed_at}"
    )[:MAX_TEXT]


def build_telegram_payload(token: str, chat_id: str, text: str) -> tuple[str, dict[str, str]]:
    """Build the URL and JSON body for sendMessage; validates boundaries."""
    token = token.strip()
    chat_id = chat_id.strip()
    if not token or any(character.isspace() for character in token):
        raise ValueError("Telegram bot token is empty or malformed")
    if not chat_id:
        raise ValueError("Telegram chat_id is empty")
    if not text:
        raise ValueError("Alert text is empty")
    return (
        f"https://api.telegram.org/bot{token}/sendMessage",
        {"chat_id": chat_id, "text": text[:MAX_TEXT]},
    )


def _validate_rule(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("rule must be an object")
    rule_type = raw.get("type")
    if rule_type not in RULE_TYPES:
        raise ValueError(f"unknown rule type: {rule_type!r}")
    value = raw.get("value")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("rule value must be a number")
    if not 0 < float(value) < 1e9:
        raise ValueError("rule value must be positive and below 1e9")
    return {"type": rule_type, "value": float(value)}


def validate_config(raw: Any) -> dict[str, Any]:
    """Validate the full configuration and return a normalized copy."""
    if not isinstance(raw, dict):
        raise ValueError("config root must be an object")

    steam = raw.get("steam")
    if not isinstance(steam, dict):
        raise ValueError("steam section is required")
    country = steam.get("country", "US")
    currency = steam.get("currency", "USD")
    currency_id = steam.get("currency_id", 1)
    delay = steam.get("request_delay_seconds", 1.5)
    timeout = steam.get("timeout_seconds", 15)
    if not isinstance(country, str) or not 1 <= len(country) <= 4:
        raise ValueError("steam.country is invalid")
    if not isinstance(currency, str) or not 1 <= len(currency) <= 4:
        raise ValueError("steam.currency is invalid")
    if isinstance(currency_id, bool) or not isinstance(currency_id, int) or currency_id <= 0:
        raise ValueError("steam.currency_id must be a positive integer")
    if not isinstance(delay, (int, float)) or not 0.1 <= float(delay) <= 60:
        raise ValueError("steam.request_delay_seconds must be between 0.1 and 60")
    if not isinstance(timeout, (int, float)) or not 1 <= float(timeout) <= 120:
        raise ValueError("steam.timeout_seconds must be between 1 and 120")

    telegram = raw.get("telegram")
    if not isinstance(telegram, dict) or not isinstance(telegram.get("chat_id"), str):
        raise ValueError("telegram.chat_id is required")
    if not telegram["chat_id"].strip():
        raise ValueError("telegram.chat_id is empty")

    watch = raw.get("watch")
    if not isinstance(watch, list) or not 1 <= len(watch) <= 100:
        raise ValueError("watch must contain between 1 and 100 items")
    normalized_watch = []
    seen: set[tuple[int, str]] = set()
    for entry in watch:
        if not isinstance(entry, dict):
            raise ValueError("each watch entry must be an object")
        appid = entry.get("appid")
        name = entry.get("market_hash_name")
        interval = entry.get("interval_seconds", 300)
        rules = entry.get("rules")
        if isinstance(appid, bool) or not isinstance(appid, int) or appid <= 0:
            raise ValueError("watch.appid must be a positive integer")
        if not isinstance(name, str) or not 1 <= len(name) <= 200:
            raise ValueError("watch.market_hash_name is invalid")
        if not isinstance(interval, (int, float)) or not 30 <= float(interval) <= 86400:
            raise ValueError("watch.interval_seconds must be between 30 and 86400")
        if not isinstance(rules, list) or not 1 <= len(rules) <= 5:
            raise ValueError("watch.rules must contain between 1 and 5 rules")
        key = (appid, name)
        if key in seen:
            raise ValueError(f"duplicate watch item: {key}")
        seen.add(key)
        normalized_watch.append(
            {
                "appid": appid,
                "market_hash_name": name,
                "interval_seconds": float(interval),
                "rules": [_validate_rule(rule) for rule in rules],
            }
        )

    cooldown = raw.get("alert_cooldown_seconds", 3600)
    if not isinstance(cooldown, (int, float)) or not 0 <= float(cooldown) <= 86400:
        raise ValueError("alert_cooldown_seconds must be between 0 and 86400")

    return {
        "steam": {
            "country": country,
            "currency": currency,
            "currency_id": currency_id,
            "request_delay_seconds": float(delay),
            "timeout_seconds": float(timeout),
        },
        "telegram": {"chat_id": telegram["chat_id"].strip()},
        "watch": normalized_watch,
        "alert_cooldown_seconds": float(cooldown),
    }
