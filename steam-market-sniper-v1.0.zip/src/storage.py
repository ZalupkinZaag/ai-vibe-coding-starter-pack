"""SQLite history for observed prices. All queries are parameterized."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterator

from .core import Observation, parse_price


class Storage:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS observations (
                    item_key TEXT NOT NULL,
                    appid INTEGER NOT NULL,
                    market_hash_name TEXT NOT NULL,
                    lowest TEXT NOT NULL,
                    median TEXT,
                    volume INTEGER,
                    currency TEXT NOT NULL,
                    observed_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_observations_item_time "
                "ON observations(item_key, observed_at DESC)"
            )

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=10)
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def item_key(appid: int, market_hash_name: str) -> str:
        return f"{appid}|{market_hash_name}"

    def record(self, observation: Observation) -> None:
        key = self.item_key(observation.appid, observation.market_hash_name)
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO observations "
                "(item_key, appid, market_hash_name, lowest, median, volume, currency, observed_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    key,
                    observation.appid,
                    observation.market_hash_name,
                    str(observation.lowest),
                    str(observation.median) if observation.median is not None else None,
                    observation.volume,
                    observation.currency,
                    observation.observed_at,
                ),
            )

    def latest(self, appid: int, market_hash_name: str) -> Observation | None:
        key = self.item_key(appid, market_hash_name)
        with self._connect() as connection:
            row = connection.execute(
                "SELECT appid, market_hash_name, lowest, median, volume, currency, observed_at "
                "FROM observations WHERE item_key = ? ORDER BY observed_at DESC LIMIT 1",
                (key,),
            ).fetchone()
        if row is None:
            return None
        lowest = parse_price(row[2])
        median = parse_price(row[3])
        if lowest is None:
            return None
        return Observation(
            appid=row[0],
            market_hash_name=row[1],
            lowest=lowest,
            median=median,
            volume=row[4],
            currency=row[5],
            observed_at=row[6],
        )

    def prune(self, days: int) -> int:
        """Delete observations older than `days`; returns the deleted count."""
        if not isinstance(days, int) or isinstance(days, bool) or not 1 <= days <= 365:
            raise ValueError("days must be an integer between 1 and 365")
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="seconds")
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM observations WHERE observed_at < ?", (cutoff,))
            return cursor.rowcount
