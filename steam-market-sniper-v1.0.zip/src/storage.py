"""SQLite history for observed prices. All queries are parameterized."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Iterator

from .core import RULE_TYPES, Observation, parse_price


class Storage:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS observations (
                    item_key TEXT NOT NULL,
                    appid INTEGER NOT NULL,
                    market_hash_name TEXT NOT NULL,
                    lowest TEXT NOT NULL,
                    median TEXT,
                    volume INTEGER,
                    currency TEXT NOT NULL,
                    observed_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_observations_item_time "
                "ON observations(item_key, observed_at DESC)"
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS watchlist (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id TEXT NOT NULL,
                    appid INTEGER NOT NULL,
                    market_hash_name TEXT NOT NULL,
                    rule_type TEXT NOT NULL,
                    rule_value TEXT NOT NULL,
                    interval_seconds INTEGER NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1
                )
                """
            )

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=10)
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    @staticmethod
    def item_key(appid: int, market_hash_name: str) -> str:
        return f"{appid}|{market_hash_name}"

    def record(self, observation: Observation) -> None:
        key = self.item_key(observation.appid, observation.market_hash_name)
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO observations "
                "(item_key, appid, market_hash_name, lowest, median, volume, currency, observed_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    key,
                    observation.appid,
                    observation.market_hash_name,
                    str(observation.lowest),
                    str(observation.median) if observation.median is not None else None,
                    observation.volume,
                    observation.currency,
                    observation.observed_at,
                ),
            )

    def latest(self, appid: int, market_hash_name: str) -> Observation | None:
        key = self.item_key(appid, market_hash_name)
        with self._connect() as connection:
            row = connection.execute(
                "SELECT appid, market_hash_name, lowest, median, volume, currency, observed_at "
                "FROM observations WHERE item_key = ? ORDER BY observed_at DESC LIMIT 1",
                (key,),
            ).fetchone()
        if row is None:
            return None
        lowest = parse_price(row[2])
        median = parse_price(row[3])
        if lowest is None:
            return None
        return Observation(
            appid=row[0],
            market_hash_name=row[1],
            lowest=lowest,
            median=median,
            volume=row[4],
            currency=row[5],
            observed_at=row[6],
        )

    def add_watch(
        self,
        chat_id: str,
        appid: int,
        market_hash_name: str,
        rule_type: str,
        rule_value: Decimal,
        interval_seconds: int = 300,
    ) -> int:
        if not isinstance(chat_id, str) or not chat_id.strip():
            raise ValueError("chat_id is empty")
        if isinstance(appid, bool) or not isinstance(appid, int) or appid <= 0:
            raise ValueError("appid must be a positive integer")
        if not isinstance(market_hash_name, str) or not 1 <= len(market_hash_name) <= 200:
            raise ValueError("market_hash_name is invalid")
        if rule_type not in RULE_TYPES:
            raise ValueError("unknown rule type")
        if not isinstance(rule_value, Decimal) or not rule_value.is_finite() or rule_value <= 0:
            raise ValueError("rule_value must be a positive Decimal")
        if not isinstance(interval_seconds, int) or not 30 <= interval_seconds <= 86400:
            raise ValueError("interval_seconds must be between 30 and 86400")
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO watchlist "
                "(chat_id, appid, market_hash_name, rule_type, rule_value, interval_seconds, enabled) "
                "VALUES (?, ?, ?, ?, ?, ?, 1)",
                (
                    chat_id.strip(),
                    appid,
                    market_hash_name,
                    rule_type,
                    str(rule_value),
                    interval_seconds,
                ),
            )
            return cursor.lastrowid

    def list_watch(self, chat_id: str | None = None) -> list[dict]:
        with self._connect() as connection:
            if chat_id is None:
                rows = connection.execute(
                    "SELECT id, chat_id, appid, market_hash_name, rule_type, rule_value, "
                    "interval_seconds, enabled FROM watchlist ORDER BY id"
                ).fetchall()
            else:
                rows = connection.execute(
                    "SELECT id, chat_id, appid, market_hash_name, rule_type, rule_value, "
                    "interval_seconds, enabled FROM watchlist WHERE chat_id = ? ORDER BY id",
                    (chat_id,),
                ).fetchall()
        return [
            {
                "id": row[0],
                "chat_id": row[1],
                "appid": row[2],
                "market_hash_name": row[3],
                "rule_type": row[4],
                "rule_value": row[5],
                "interval_seconds": row[6],
                "enabled": bool(row[7]),
            }
            for row in rows
        ]

    def delete_watch(self, item_id: int, chat_id: str) -> bool:
        if not isinstance(item_id, int) or isinstance(item_id, bool) or item_id <= 0:
            raise ValueError("item_id must be a positive integer")
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM watchlist WHERE id = ? AND chat_id = ?", (item_id, chat_id)
            )
            return cursor.rowcount > 0

    def set_watch_value(self, item_id: int, chat_id: str, rule_value: Decimal) -> bool:
        if not isinstance(item_id, int) or isinstance(item_id, bool) or item_id <= 0:
            raise ValueError("item_id must be a positive integer")
        if not isinstance(rule_value, Decimal) or not rule_value.is_finite() or rule_value <= 0:
            raise ValueError("rule_value must be a positive Decimal")
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE watchlist SET rule_value = ? WHERE id = ? AND chat_id = ?",
                (str(rule_value), item_id, chat_id),
            )
            return cursor.rowcount > 0

    def toggle_watch(self, item_id: int, chat_id: str) -> bool:
        if not isinstance(item_id, int) or isinstance(item_id, bool) or item_id <= 0:
            raise ValueError("item_id must be a positive integer")
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE watchlist SET enabled = 1 - enabled WHERE id = ? AND chat_id = ?",
                (item_id, chat_id),
            )
            return cursor.rowcount > 0

    def prune(self, days: int) -> int:
        """Delete observations older than `days`; returns the deleted count."""
        if not isinstance(days, int) or isinstance(days, bool) or not 1 <= days <= 365:
            raise ValueError("days must be an integer between 1 and 365")
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="seconds")
        with self._connect() as connection:
            cursor = connection.execute("DELETE FROM observations WHERE observed_at < ?", (cutoff,))
            return cursor.rowcount
