"""Steam Market sniper package."""
