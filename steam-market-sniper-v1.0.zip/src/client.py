"""Async Steam Community Market client with bounded retries and validation."""

from __future__ import annotations

import asyncio

import httpx

from .core import Observation, parse_priceoverview

URL = "https://steamcommunity.com/market/priceoverview/"
MAX_RESPONSE_CHARS = 100_000
MAX_ATTEMPTS = 3
RETRYABLE_PREFIXES = ("HTTP 429", "HTTP 5")


class SteamError(RuntimeError):
    """Raised when Steam cannot be reached or returns unusable data."""


class SteamClient:
    def __init__(self, settings: dict, http: httpx.AsyncClient) -> None:
        self.settings = settings
        self.http = http

    async def fetch(self, appid: int, market_hash_name: str) -> Observation:
        params = {
            "country": self.settings["country"],
            "currency": str(self.settings["currency_id"]),
            "appid": str(appid),
            "market_hash_name": market_hash_name,
        }
        referer = (
            "https://steamcommunity.com/market/listings/"
            f"{appid}/{market_hash_name.replace(' ', '%20')}"
        )
        headers = {
            "Accept": "application/json",
            "Referer": referer,
            "User-Agent": "steam-sniper/1.0",
        }
        timeout = httpx.Timeout(float(self.settings["timeout_seconds"]))
        last_error = "unknown error"

        for attempt in range(MAX_ATTEMPTS):
            try:
                response = await self.http.get(
                    URL, params=params, headers=headers, timeout=timeout
                )
                status = response.status_code
                if status == 429 or 500 <= status < 600:
                    message = f"HTTP {status}"
                    if attempt + 1 < MAX_ATTEMPTS:
                        last_error = message
                        await asyncio.sleep(float(2**attempt))
                        continue
                    raise SteamError(message)
                if status != 200:
                    raise SteamError(f"HTTP {status}")

                text = response.text
                if len(text) > MAX_RESPONSE_CHARS:
                    raise SteamError("response too large")
                if text.lstrip().startswith("<"):
                    raise SteamError("Steam returned HTML instead of JSON")
                try:
                    payload = response.json()
                except ValueError as exc:
                    raise SteamError(f"malformed JSON: {exc}") from exc

                observation = parse_priceoverview(
                    payload,
                    appid=appid,
                    market_hash_name=market_hash_name,
                    currency=self.settings["currency"],
                )
                if observation is None:
                    raise SteamError("payload failed validation")
                return observation
            except httpx.HTTPError as exc:
                last_error = str(exc)
                if attempt + 1 < MAX_ATTEMPTS:
                    await asyncio.sleep(float(2**attempt))
            except SteamError as exc:
                message = str(exc)
                if message.startswith(RETRYABLE_PREFIXES) and attempt + 1 < MAX_ATTEMPTS:
                    last_error = message
                    await asyncio.sleep(float(2**attempt))
                    continue
                raise

        raise SteamError(f"failed after {MAX_ATTEMPTS} attempts: {last_error}")
