"""Pure validation and file writing used by the setup wizard."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

TOKEN_PATTERN = re.compile(r"^\d+:[A-Za-z0-9_-]{20,}$")


def validate_values(values: dict[str, Any]) -> dict[str, Any]:
    """Validate wizard input and return a normalized config."""
    token = str(values.get("token", "")).strip()
    chat_id = str(values.get("chat_id", "")).strip()
    if not TOKEN_PATTERN.match(token):
        raise ValueError("Токен бота выглядит некорректно. Ожидается вид 123456:ABC...")
    if not chat_id.isdigit():
        raise ValueError("Chat ID должен быть числом из Telegram")

    country = str(values.get("country", "US")).strip() or "US"
    currency = str(values.get("currency", "USD")).strip() or "USD"
    if not 1 <= len(country) <= 4 or not 1 <= len(currency) <= 4:
        raise ValueError("Регион или валюта слишком длинные")

    try:
        appid = int(values.get("appid", 730))
        currency_id = int(values.get("currency_id", 1) or 1)
        threshold = float(values.get("threshold", 25))
        delay = float(values.get("delay", 1.5))
        cooldown = float(values.get("cooldown", 3600))
    except (TypeError, ValueError) as exc:
        raise ValueError("Числа введены некорректно") from exc
    if appid <= 0:
        raise ValueError("App ID должен быть положительным")
    if currency_id <= 0:
        raise ValueError("ID валюты должен быть положительным")
    if not 0 < threshold < 1e9:
        raise ValueError("Порог должен быть положительным числом")
    if not 0.1 <= delay <= 60:
        raise ValueError("Задержка запроса должна быть от 0.1 до 60 секунд")
    if not 0 <= cooldown <= 86400:
        raise ValueError("Cooldown должен быть от 0 до 86400 секунд")

    name = str(values.get("market_hash_name", "")).strip()
    if not 1 <= len(name) <= 200:
        raise ValueError("Название предмета пустое или слишком длинное")

    rule_type = str(values.get("rule_type", "below"))
    if rule_type not in {"below", "drop_pct", "rise_pct"}:
        raise ValueError("Неизвестный тип правила")

    return {
        "steam": {
            "country": country,
            "currency": currency,
            "currency_id": currency_id,
            "request_delay_seconds": delay,
            "timeout_seconds": 15,
        },
        "telegram": {"chat_id": chat_id},
        "watch": [
            {
                "appid": appid,
                "market_hash_name": name,
                "interval_seconds": 300,
                "rules": [{"type": rule_type, "value": threshold}],
            }
        ],
        "alert_cooldown_seconds": cooldown,
        "_token": token,
    }


def write_config(directory: str | Path, values: dict[str, Any]) -> list[str]:
    """Write config.json, config.actions.json and .env. Returns created file names."""
    config = validate_values(values)
    token = config.pop("_token")
    target = Path(directory)
    target.mkdir(parents=True, exist_ok=True)

    config_text = json.dumps(config, ensure_ascii=False, indent=2)
    (target / "config.json").write_text(config_text, encoding="utf-8")
    (target / "config.actions.json").write_text(config_text, encoding="utf-8")
    (target / ".env").write_text(f"TELEGRAM_BOT_TOKEN={token}\n", encoding="utf-8")
    return ["config.json", "config.actions.json", ".env"]
