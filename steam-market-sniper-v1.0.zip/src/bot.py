"""Interactive Telegram bot: search Steam items and manage the watchlist."""

from __future__ import annotations

import asyncio
import logging
import os
from decimal import Decimal

import httpx
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from .core import parse_price, parse_search
from .storage import Storage

SEARCH_URL = "https://steamcommunity.com/market/search/render/"
logger = logging.getLogger("steam_sniper_bot")

storage: Storage
allowed_chat: str
pending: dict[str, object] = {}
search_cache: dict[str, list[dict]] = {}


def main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔍 Найти товар", callback_data="search")],
            [
                InlineKeyboardButton(text="📋 Мои товары", callback_data="my"),
                InlineKeyboardButton(text="ℹ️ Помощь", callback_data="help"),
            ],
        ]
    )


def results_keyboard(items: list[dict]) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=f"{index + 1}. {item['name'][:32]} | {item['price_text']}",
                callback_data=f"add:{index}",
            )
        ]
        for index, item in enumerate(items)
    ]
    rows.append([InlineKeyboardButton(text="« Меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def item_keyboard(item: dict) -> InlineKeyboardMarkup:
    item_id = item["id"]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🎯 Порог", callback_data=f"th:{item_id}"),
                InlineKeyboardButton(text="⏸ Пауза", callback_data=f"tog:{item_id}"),
            ],
            [InlineKeyboardButton(text="🗑 Удалить", callback_data=f"del:{item_id}")],
        ]
    )


def is_allowed(chat_id: int) -> bool:
    return str(chat_id) == allowed_chat


async def cmd_start(message: Message) -> None:
    if not is_allowed(message.chat.id):
        return
    await message.answer(
        "Steam Market Sniper\n\n"
        "Найди товар по названию и поставь его на мониторинг. "
        "Нажми кнопку ниже, чтобы начать.",
        reply_markup=main_keyboard(),
    )


async def cmd_help(message: Message) -> None:
    if not is_allowed(message.chat.id):
        return
    await message.answer(
        "Кнопки:\n"
        "• Найти товар — поиск по Steam Market, затем выбор из списка и порог цены.\n"
        "• Мои товары — список с порогами, паузой и удалением.\n"
        "Правило по умолчанию: оповещение, если цена станет ниже порога.",
        reply_markup=main_keyboard(),
    )


async def cb_menu(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    await query.message.edit_text("Меню:", reply_markup=main_keyboard())
    await query.answer()


async def cb_help(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    await query.message.edit_text(
        "Найди товар → выбери результат → введи порог. "
        "В списке своих товаров можно менять порог, ставить на паузу и удалять.",
        reply_markup=main_keyboard(),
    )
    await query.answer()


async def cb_search(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    pending[str(query.from_user.id)] = "search"
    await query.message.edit_text("Напиши название предмета, например: AK-47 Redline")
    await query.answer()


async def cb_my(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    rows = storage.list_watch(str(query.from_user.id))
    if not rows:
        await query.message.edit_text("Список пуст. Добавь товар через поиск.", reply_markup=main_keyboard())
        await query.answer()
        return
    keyboard_rows = []
    for row in rows:
        keyboard_rows.append(
            [
                InlineKeyboardButton(
                    text=f"{'✅' if row['enabled'] else '⏸'} {row['market_hash_name'][:28]} | {row['rule_value']}",
                    callback_data=f"noop:{row['id']}",
                )
            ]
        )
        keyboard_rows.append(
            [
                InlineKeyboardButton(text="🎯 Порог", callback_data=f"th:{row['id']}"),
                InlineKeyboardButton(text="⏸ Пауза", callback_data=f"tog:{row['id']}"),
                InlineKeyboardButton(text="🗑", callback_data=f"del:{row['id']}"),
            ]
        )
    keyboard_rows.append([InlineKeyboardButton(text="« Меню", callback_data="menu")])
    await query.message.edit_text(
        "Твои товары:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard_rows),
    )
    await query.answer()


async def cb_add(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    chat_key = str(query.from_user.id)
    try:
        index = int(query.data.split(":", 1)[1])
    except (ValueError, IndexError):
        await query.answer("Некорректный номер", show_alert=True)
        return
    items = search_cache.get(chat_key, [])
    if not 0 <= index < len(items):
        await query.answer("Результат устарел, повтори поиск", show_alert=True)
        return
    pending[chat_key] = ("add", items[index])
    await query.message.edit_text(
        f"Товар: {items[index]['name']}\nТекущая цена: {items[index]['price_text'] or 'н/д'}\n"
        "Напиши порог цены, например 25"
    )
    await query.answer()


async def cb_threshold(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    try:
        item_id = int(query.data.split(":", 1)[1])
    except (ValueError, IndexError):
        await query.answer("Некорректный номер", show_alert=True)
        return
    pending[str(query.from_user.id)] = ("threshold", item_id)
    await query.message.edit_text("Напиши новый порог цены, например 25")
    await query.answer()


async def cb_delete(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    try:
        item_id = int(query.data.split(":", 1)[1])
    except (ValueError, IndexError):
        await query.answer("Некорректный номер", show_alert=True)
        return
    deleted = storage.delete_watch(item_id, str(query.from_user.id))
    await query.message.edit_text("Удалено" if deleted else "Запись не найдена", reply_markup=main_keyboard())
    await query.answer()


async def cb_toggle(query: CallbackQuery) -> None:
    if not is_allowed(query.from_user.id):
        return
    try:
        item_id = int(query.data.split(":", 1)[1])
    except (ValueError, IndexError):
        await query.answer("Некорректный номер", show_alert=True)
        return
    changed = storage.toggle_watch(item_id, str(query.from_user.id))
    await query.message.edit_text("Статус изменён" if changed else "Запись не найдена", reply_markup=main_keyboard())
    await query.answer()


async def cb_noop(query: CallbackQuery) -> None:
    await query.answer()


async def on_message(message: Message) -> None:
    if not is_allowed(message.chat.id) or not message.text:
        return
    chat_key = str(message.chat.id)
    state = pending.get(chat_key)

    if state == "search":
        text = message.text.strip()[:100]
        async with httpx.AsyncClient() as http:
            try:
                response = await http.get(
                    SEARCH_URL,
                    params={"query": text, "appid": 730, "start": 0, "count": 5, "norender": 1},
                    headers={"Accept": "application/json"},
                    timeout=httpx.Timeout(15.0),
                )
            except httpx.HTTPError as exc:
                await message.answer(f"Не удалось связаться со Steam: {exc}")
                pending.pop(chat_key, None)
                return
        if response.status_code != 200:
            await message.answer(f"Steam вернул HTTP {response.status_code}")
            pending.pop(chat_key, None)
            return
        try:
            payload = response.json()
        except ValueError:
            await message.answer("Steam вернул не JSON")
            pending.pop(chat_key, None)
            return
        items = parse_search(payload, 5)
        if not items:
            await message.answer("Ничего не найдено. Попробуй другое название.", reply_markup=main_keyboard())
            pending.pop(chat_key, None)
            return
        search_cache[chat_key] = items
        lines = "\n".join(
            f"{index + 1}. {item['name']} — {item['price_text'] or 'н/д'}"
            for index, item in enumerate(items)
        )
        await message.answer("Выбери товар:", reply_markup=results_keyboard(items))
        logger.info("search results: %s", lines)
        pending.pop(chat_key, None)
        return

    if isinstance(state, tuple) and state and state[0] == "add":
        item = state[1]
        value = parse_price(message.text.strip())
        if value is None or value <= 0:
            await message.answer("Некорректная цена. Введи число, например 25")
            return
        item_id = storage.add_watch(
            chat_key, item["appid"], item["hash_name"], "below", value
        )
        pending.pop(chat_key, None)
        await message.answer(
            f"Добавлено #{item_id}: {item['hash_name']}\nПорог: {value}",
            reply_markup=main_keyboard(),
        )
        return

    if isinstance(state, tuple) and state and state[0] == "threshold":
        item_id = state[1]
        value = parse_price(message.text.strip())
        if value is None or value <= 0:
            await message.answer("Некорректная цена. Введи число, например 25")
            return
        updated = storage.set_watch_value(item_id, chat_key, value)
        pending.pop(chat_key, None)
        await message.answer("Порог обновлён" if updated else "Запись не найдена", reply_markup=main_keyboard())
        return

    await message.answer("Выбери действие в меню:", reply_markup=main_keyboard())


async def run_bot() -> None:
    global storage, allowed_chat
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    allowed_chat = os.environ.get("TELEGRAM_CHAT_ID", "").strip()
    if not token or not allowed_chat:
        raise SystemExit("TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID are required")
    storage = Storage(os.environ.get("SNIPER_DB", "history.db"))

    bot = Bot(token=token)
    dispatcher = Dispatcher()
    dispatcher.message.register(cmd_start, CommandStart())
    dispatcher.message.register(cmd_help, Command("help"))
    dispatcher.message.register(on_message)
    dispatcher.callback_query.register(cb_menu, F.data == "menu")
    dispatcher.callback_query.register(cb_help, F.data == "help")
    dispatcher.callback_query.register(cb_search, F.data == "search")
    dispatcher.callback_query.register(cb_my, F.data == "my")
    dispatcher.callback_query.register(cb_add, F.data.startswith("add:"))
    dispatcher.callback_query.register(cb_threshold, F.data.startswith("th:"))
    dispatcher.callback_query.register(cb_delete, F.data.startswith("del:"))
    dispatcher.callback_query.register(cb_toggle, F.data.startswith("tog:"))
    dispatcher.callback_query.register(cb_noop, F.data.startswith("noop:"))

    await dispatcher.start_polling(bot)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    asyncio.run(run_bot())


if __name__ == "__main__":
    raise SystemExit(main())
