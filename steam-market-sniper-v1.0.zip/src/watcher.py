"""Polling loop. Uses per-item intervals and a global request delay."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Awaitable, Callable

from .client import SteamClient
from .core import build_alert_text, evaluate_rule, is_cooldown_over
from .storage import Storage

logger = logging.getLogger(__name__)
SendFunc = Callable[[str], Awaitable[None]]


async def run_once(
    config: dict,
    client: SteamClient,
    storage: Storage,
    send: SendFunc,
) -> int:
    """Run a single check of every item. Returns the number of alerts sent."""
    sent = 0
    for item in config["watch"]:
        appid = item["appid"]
        name = item["market_hash_name"]
        try:
            observation = await client.fetch(appid, name)
        except Exception as exc:
            logger.warning("fetch failed for %s: %s", (appid, name), exc)
            continue

        previous = storage.latest(appid, name)
        storage.record(observation)
        previous_lowest = previous.lowest if previous is not None else None
        for rule in item["rules"]:
            if not evaluate_rule(rule["type"], rule["value"], observation.lowest, previous_lowest):
                continue
            text = build_alert_text(observation, rule["type"], rule["value"])
            try:
                await send(text)
            except Exception as exc:
                logger.warning("alert delivery failed: %s", exc)
            else:
                sent += 1
    return sent


async def run(
    config: dict,
    client: SteamClient,
    storage: Storage,
    send: SendFunc,
    stop_event: asyncio.Event,
) -> None:
    cooldown = config["alert_cooldown_seconds"]
    request_delay = config["steam"]["request_delay_seconds"]
    next_due: dict[tuple[int, str], float] = {}
    last_alert: dict[tuple[int, str, int], float] = {}

    while not stop_event.is_set():
        now = time.time()
        for item in config["watch"]:
            if stop_event.is_set():
                break
            key = (item["appid"], item["market_hash_name"])
            if now < next_due.get(key, 0.0):
                continue

            try:
                observation = await client.fetch(key[0], key[1])
            except Exception as exc:
                logger.warning("fetch failed for %s: %s", key, exc)
                next_due[key] = time.time() + item["interval_seconds"]
                await asyncio.sleep(request_delay)
                continue

            previous = storage.latest(key[0], key[1])
            storage.record(observation)
            previous_lowest = previous.lowest if previous is not None else None

            for index, rule in enumerate(item["rules"]):
                if not evaluate_rule(rule["type"], rule["value"], observation.lowest, previous_lowest):
                    continue
                alert_key = (key[0], key[1], index)
                current_time = time.time()
                if not is_cooldown_over(last_alert.get(alert_key), current_time, cooldown):
                    continue
                text = build_alert_text(observation, rule["type"], rule["value"])
                try:
                    await send(text)
                except Exception as exc:
                    logger.warning("alert delivery failed: %s", exc)
                else:
                    last_alert[alert_key] = current_time
                    logger.info("alert sent: %s %s", key, rule["type"])

            next_due[key] = time.time() + item["interval_seconds"]
            await asyncio.sleep(request_delay)

        if not next_due:
            break
        wait = max(0.0, min(next_due.values()) - time.time())
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=min(wait, 1.0))
        except asyncio.TimeoutError:
            pass
