"""Telegram delivery with validation of the Bot API response."""

from __future__ import annotations

import asyncio

import httpx

from .core import build_telegram_payload

TELEGRAM_TIMEOUT = 15.0
MAX_ATTEMPTS = 3


async def send_alert(
    http: httpx.AsyncClient,
    token: str,
    chat_id: str,
    text: str,
) -> None:
    url, payload = build_telegram_payload(token, chat_id, text)
    last_error = "unknown error"
    for attempt in range(MAX_ATTEMPTS):
        try:
            response = await http.post(url, json=payload, timeout=TELEGRAM_TIMEOUT)
        except httpx.HTTPError as exc:
            last_error = str(exc) or type(exc).__name__
            if attempt + 1 < MAX_ATTEMPTS:
                await asyncio.sleep(float(2**attempt))
                continue
            raise RuntimeError(f"Telegram network error: {last_error}") from exc

        if response.status_code != 200:
            raise RuntimeError(f"Telegram returned HTTP {response.status_code}")
        try:
            data = response.json()
        except ValueError as exc:
            raise RuntimeError("Telegram returned malformed JSON") from exc
        if not isinstance(data, dict) or data.get("ok") is not True:
            raise RuntimeError("Telegram response has ok=false")
        return

    raise RuntimeError(f"Telegram delivery failed: {last_error}")
