"""Telegram delivery with validation of the Bot API response."""

from __future__ import annotations

import httpx

from .core import build_telegram_payload

TELEGRAM_TIMEOUT = 15.0


async def send_alert(
    http: httpx.AsyncClient,
    token: str,
    chat_id: str,
    text: str,
) -> None:
    url, payload = build_telegram_payload(token, chat_id, text)
    response = await http.post(url, json=payload, timeout=TELEGRAM_TIMEOUT)
    if response.status_code != 200:
        raise RuntimeError(f"Telegram returned HTTP {response.status_code}")
    try:
        data = response.json()
    except ValueError as exc:
        raise RuntimeError("Telegram returned malformed JSON") from exc
    if not isinstance(data, dict) or data.get("ok") is not True:
        raise RuntimeError("Telegram response has ok=false")
