"""Simple GUI wizard that fills config.json, config.actions.json and .env.

Run: python setup_wizard.py
The token is written only to .env, never to the JSON configs.
"""

from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from src.setup_config import write_config

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config.json"

FIELDS = [
    ("Токен бота (BotFather)", "token", ""),
    ("Chat ID (число)", "chat_id", ""),
    ("App ID игры (730 = CS2)", "appid", "730"),
    ("Название предмета", "market_hash_name", "AK-47 | Redline (Field-Tested)"),
    ("Правило (below/drop_pct/rise_pct)", "rule_type", "below"),
    ("Порог цены", "threshold", "25"),
    ("Регион", "country", "US"),
    ("Валюта", "currency", "USD"),
    ("ID валюты", "currency_id", "1"),
    ("Задержка запроса, сек", "delay", "1.5"),
    ("Cooldown, сек", "cooldown", "3600"),
]


def load_defaults() -> dict[str, str]:
    defaults = {key: default for _, key, default in FIELDS}
    if CONFIG.exists():
        try:
            data = json.loads(CONFIG.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return defaults
        steam = data.get("steam", {})
        watch = (data.get("watch") or [{}])[0]
        rule = (watch.get("rules") or [{}])[0]
        defaults.update(
            {
                "chat_id": str(data.get("telegram", {}).get("chat_id", "")),
                "appid": str(watch.get("appid", defaults["appid"])),
                "market_hash_name": str(watch.get("market_hash_name", defaults["market_hash_name"])),
                "rule_type": str(rule.get("type", defaults["rule_type"])),
                "threshold": str(rule.get("value", defaults["threshold"])),
                "country": str(steam.get("country", defaults["country"])),
                "currency": str(steam.get("currency", defaults["currency"])),
                "currency_id": str(steam.get("currency_id", defaults["currency_id"])),
                "delay": str(steam.get("request_delay_seconds", defaults["delay"])),
                "cooldown": str(data.get("alert_cooldown_seconds", defaults["cooldown"])),
            }
        )
    return defaults


def build_window() -> tk.Tk:
    window = tk.Tk()
    window.title("Steam Market Sniper — настройка")
    window.resizable(False, False)
    defaults = load_defaults()
    entries: dict[str, ttk.Entry] = {}

    frame = ttk.Frame(window, padding=12)
    frame.grid(row=0, column=0, sticky="nsew")

    for index, (label, key, _) in enumerate(FIELDS):
        ttk.Label(frame, text=label).grid(row=index, column=0, sticky="w", pady=3)
        entry = ttk.Entry(frame, width=54, show="*" if key == "token" else None)
        entry.grid(row=index, column=1, pady=3)
        entry.insert(0, defaults.get(key, ""))
        entries[key] = entry

    def save() -> None:
        values = {key: entry.get().strip() for key, entry in entries.items()}
        try:
            files = write_config(ROOT, values)
        except ValueError as exc:
            messagebox.showerror("Ошибка", str(exc))
            return
        messagebox.showinfo(
            "Готово",
            "Созданы файлы:\n" + "\n".join(files) + "\n\nТокен записан только в .env.",
        )

    buttons = ttk.Frame(frame)
    buttons.grid(row=len(FIELDS), column=0, columnspan=2, pady=(12, 0))
    ttk.Button(buttons, text="Сохранить", command=save).pack(side="left", padx=(0, 8))
    ttk.Button(buttons, text="Закрыть", command=window.destroy).pack(side="left")
    return window


def main() -> None:
    build_window().mainloop()


if __name__ == "__main__":
    raise SystemExit(main())
