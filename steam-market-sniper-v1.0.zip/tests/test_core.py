from decimal import Decimal

import pytest

from src.core import (
    MAX_TEXT,
    Observation,
    build_alert_text,
    build_telegram_payload,
    evaluate_rule,
    is_cooldown_over,
    parse_price,
    parse_priceoverview,
    parse_search,
    parse_volume,
    validate_config,
)


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("$1,234.56", Decimal("1234.56")),
        ("1.234,56 €", Decimal("1234.56")),
        ("1 234,56 ₽", Decimal("1234.56")),
        ("$9.99", Decimal("9.99")),
        ("12,5", Decimal("12.5")),
        ("0", Decimal("0")),
        (42, Decimal("42")),
        (Decimal("3.50"), Decimal("3.50")),
        ("$1,234,567.89", Decimal("1234567.89")),
        ("", None),
        (None, None),
        ("abc", None),
        ("$-5.00", Decimal("-5.00")),
        ("1e309", None),
        (True, None),
        ([], None),
    ],
)
def test_parse_price(raw, expected):
    assert parse_price(raw) == expected


def test_parse_price_rejects_absurd_values():
    assert parse_price("1000000001") is None
    assert parse_price(-1) is None
    assert parse_price(float("nan")) is None
    assert parse_price(float("inf")) is None


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("1,234", 1234),
        ("12 345", 12345),
        (7, 7),
        ("", None),
        (None, None),
        ("12.5", 125),
        (10**13, None),
    ],
)
def test_parse_volume(raw, expected):
    assert parse_volume(raw) == expected


def test_parse_priceoverview_valid():
    observation = parse_priceoverview(
        {
            "success": True,
            "lowest_price": "$12.34",
            "median_price": "$13.00",
            "volume": "1,234",
        },
        appid=730,
        market_hash_name="AK-47 | Redline (Field-Tested)",
        currency="USD",
    )
    assert observation is not None
    assert observation.lowest == Decimal("12.34")
    assert observation.median == Decimal("13")
    assert observation.volume == 1234
    assert observation.currency == "USD"
    assert observation.observed_at.endswith("Z") is False  # ISO with +00:00


@pytest.mark.parametrize(
    "payload",
    [
        None,
        {},
        {"success": False, "lowest_price": "$1"},
        {"success": True},
        {"success": True, "lowest_price": "bad"},
        {"success": True, "lowest_price": "$1", "median_price": "bad"},
        {"success": True, "lowest_price": "$1", "volume": "bad"},
    ],
)
def test_parse_priceoverview_invalid(payload):
    assert (
        parse_priceoverview(
            payload, appid=730, market_hash_name="X", currency="USD"
        )
        is None
    )


def test_evaluate_rule_below():
    assert evaluate_rule("below", 10, Decimal("9.99"), None) is True
    assert evaluate_rule("below", 10, Decimal("10"), None) is True
    assert evaluate_rule("below", 10, Decimal("10.01"), None) is False


def test_evaluate_rule_drop_pct():
    assert evaluate_rule("drop_pct", 5, Decimal("95"), Decimal("100")) is True
    assert evaluate_rule("drop_pct", 5, Decimal("96"), Decimal("100")) is False
    assert evaluate_rule("drop_pct", 5, Decimal("95"), None) is False
    assert evaluate_rule("drop_pct", 5, Decimal("95"), Decimal("0")) is False


def test_evaluate_rule_rise_pct():
    assert evaluate_rule("rise_pct", 10, Decimal("110"), Decimal("100")) is True
    assert evaluate_rule("rise_pct", 10, Decimal("109"), Decimal("100")) is False


@pytest.mark.parametrize("rule_type", ["unknown", "", None])
def test_evaluate_rule_rejects_unknown(rule_type):
    assert evaluate_rule(rule_type, 5, Decimal("1"), Decimal("2")) is False


def test_evaluate_rule_rejects_bad_values():
    assert evaluate_rule("below", 0, Decimal("1"), None) is False
    assert evaluate_rule("below", -1, Decimal("1"), None) is False


def test_cooldown():
    assert is_cooldown_over(None, 100, 60) is True
    assert is_cooldown_over(10, 69, 60) is False
    assert is_cooldown_over(10, 70, 60) is True
    assert is_cooldown_over(10, 5, 60) is True
    assert is_cooldown_over(10, 20, 0) is True


def test_build_alert_text_and_payload():
    observation = Observation(
        appid=730,
        market_hash_name="X",
        lowest=Decimal("5"),
        median=Decimal("6"),
        volume=10,
        currency="USD",
        observed_at="2026-11-22T00:00:00+00:00",
    )
    text = build_alert_text(observation, "below", 10)
    assert "X" in text and "below" in text
    url, body = build_telegram_payload(" 123:ABC ", " 42 ", text)
    assert url == "https://api.telegram.org/bot123:ABC/sendMessage"
    assert body == {"chat_id": "42", "text": text}
    assert len(body["text"]) <= MAX_TEXT


@pytest.mark.parametrize(
    "token, chat_id, text",
    [
        ("", "1", "x"),
        ("a b", "1", "x"),
        ("123:ABC", "", "x"),
        ("123:ABC", "1", ""),
    ],
)
def test_build_telegram_payload_rejects_invalid(token, chat_id, text):
    with pytest.raises(ValueError):
        build_telegram_payload(token, chat_id, text)


def test_validate_config_valid():
    raw = {
        "steam": {"country": "US", "currency": "USD", "currency_id": 1},
        "telegram": {"chat_id": "42"},
        "watch": [
            {
                "appid": 730,
                "market_hash_name": "AK-47 | Redline (Field-Tested)",
                "rules": [{"type": "below", "value": 10}],
            }
        ],
    }
    config = validate_config(raw)
    assert config["watch"][0]["rules"][0]["value"] == 10.0
    assert config["alert_cooldown_seconds"] == 3600.0


@pytest.mark.parametrize(
    "mutation",
    [
        lambda c: c.update(steam=None),
        lambda c: c["steam"].update(currency_id=0),
        lambda c: c["steam"].update(request_delay_seconds=100),
        lambda c: c.update(telegram={"chat_id": ""}),
        lambda c: c.update(watch=[]),
        lambda c: c["watch"][0].update(appid=0),
        lambda c: c["watch"][0].update(market_hash_name=""),
        lambda c: c["watch"][0].update(interval_seconds=1),
        lambda c: c["watch"][0].update(rules=[]),
        lambda c: c["watch"][0].update(rules=[{"type": "bad", "value": 1}]),
        lambda c: c["watch"][0].update(rules=[{"type": "below", "value": -1}]),
        lambda c: c.update(alert_cooldown_seconds=999999),
        lambda c: c["watch"].append(dict(c["watch"][0])),
    ],
)
def test_validate_config_rejects_invalid(mutation):
    raw = {
        "steam": {"country": "US", "currency": "USD", "currency_id": 1},
        "telegram": {"chat_id": "42"},
        "watch": [
            {
                "appid": 730,
                "market_hash_name": "X",
                "interval_seconds": 300,
                "rules": [{"type": "below", "value": 10}],
            }
        ],
    }
    mutation(raw)
    with pytest.raises(ValueError):
        validate_config(raw)


def test_parse_search_valid():
    payload = {
        "success": True,
        "results": [
            {
                "name": "AK-47 | Redline (Field-Tested)",
                "hash_name": "AK-47 | Redline (Field-Tested)",
                "appid": 730,
                "sell_price_text": "$29.30",
            },
            {"name": "Broken", "hash_name": "", "appid": 730},
            {"name": "No appid", "hash_name": "X"},
            "not a dict",
        ],
    }
    items = parse_search(payload, 5)
    assert len(items) == 1
    assert items[0]["hash_name"] == "AK-47 | Redline (Field-Tested)"
    assert items[0]["price_text"] == "$29.30"


@pytest.mark.parametrize(
    "payload",
    [None, {}, {"success": False}, {"success": True}, {"success": True, "results": "x"}],
)
def test_parse_search_invalid(payload):
    assert parse_search(payload) == []


def test_parse_search_respects_limit():
    payload = {
        "success": True,
        "results": [
            {"name": f"Item {i}", "hash_name": f"Item {i}", "appid": 730}
            for i in range(10)
        ],
    }
    assert len(parse_search(payload, 3)) == 3
