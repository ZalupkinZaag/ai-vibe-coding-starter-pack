import asyncio
from decimal import Decimal

import pytest

from src.core import Observation
from src.watcher import run


def observation(lowest: str, second: int = 0) -> Observation:
    return Observation(
        appid=730,
        market_hash_name="X",
        lowest=Decimal(lowest),
        median=None,
        volume=None,
        currency="USD",
        observed_at=f"2026-11-22T00:00:{second:02d}+00:00",
    )


class FakeStorage:
    def __init__(self):
        self.records = []
        self.current = None

    def record(self, item):
        self.records.append(item)
        self.current = item

    def latest(self, appid, name):
        return self.current


class FakeClient:
    def __init__(self, items, stop_event, stop_after):
        self.items = items
        self.stop_event = stop_event
        self.stop_after = stop_after
        self.calls = 0

    async def fetch(self, appid, name):
        item = self.items[min(self.calls, len(self.items) - 1)]
        self.calls += 1
        if self.calls >= self.stop_after:
            self.stop_event.set()
        return item


def config():
    return {
        "steam": {
            "country": "US",
            "currency": "USD",
            "currency_id": 1,
            "request_delay_seconds": 0.01,
            "timeout_seconds": 1,
        },
        "telegram": {"chat_id": "42"},
        "watch": [
            {
                "appid": 730,
                "market_hash_name": "X",
                "interval_seconds": 30,
                "rules": [{"type": "below", "value": 10.0}],
            }
        ],
        "alert_cooldown_seconds": 3600,
    }


def test_run_stops_immediately_if_stop_is_set():
    async def scenario():
        stop = asyncio.Event()
        stop.set()
        client = FakeClient([observation("1")], stop, 1)
        storage = FakeStorage()
        sent = []

        async def send(text):
            sent.append(text)

        await run(config(), client, storage, send, stop)
        return client.calls, sent

    calls, sent = asyncio.run(scenario())
    assert calls == 0
    assert sent == []


def test_run_alerts_once_because_of_cooldown():
    async def scenario():
        stop = asyncio.Event()
        client = FakeClient(
            [observation("20", 0), observation("9", 1)], stop, stop_after=2
        )
        storage = FakeStorage()
        sent = []

        async def send(text):
            sent.append(text)

        await run(config(), client, storage, send, stop)
        return client.calls, sent, storage.records

    calls, sent, records = asyncio.run(scenario())
    assert calls == 2
    assert len(records) == 2
    assert len(sent) == 1
    assert "below" in sent[0]
