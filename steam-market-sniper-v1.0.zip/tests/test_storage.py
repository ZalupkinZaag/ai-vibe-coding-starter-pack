from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest

from src.core import Observation
from src.storage import Storage


def make_observation(name="AK-47 | Redline (Field-Tested)", lowest="10.50"):
    return Observation(
        appid=730,
        market_hash_name=name,
        lowest=Decimal(lowest),
        median=Decimal("11.00"),
        volume=123,
        currency="USD",
        observed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )


def test_record_and_latest(tmp_path):
    storage = Storage(tmp_path / "history.db")
    assert storage.latest(730, "X' OR 1=1 --") is None
    observation = make_observation("X' OR 1=1 --")
    storage.record(observation)
    loaded = storage.latest(730, "X' OR 1=1 --")
    assert loaded is not None
    assert loaded.lowest == Decimal("10.50")
    assert loaded.median == Decimal("11.00")
    assert loaded.volume == 123


def test_latest_returns_newest(tmp_path):
    storage = Storage(tmp_path / "history.db")
    first = make_observation(lowest="20")
    storage.record(first)
    second = Observation(
        appid=730,
        market_hash_name=first.market_hash_name,
        lowest=Decimal("19"),
        median=None,
        volume=None,
        currency="USD",
        observed_at=(datetime.now(timezone.utc) + timedelta(seconds=1)).isoformat(timespec="seconds"),
    )
    storage.record(second)
    loaded = storage.latest(730, first.market_hash_name)
    assert loaded is not None
    assert loaded.lowest == Decimal("19")
    assert loaded.median is None
    assert loaded.volume is None


def test_prune(tmp_path):
    storage = Storage(tmp_path / "history.db")
    connection = storage._connect()
    with connection as db:
        db.execute(
            "INSERT INTO observations VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("old", 730, "old", "1", None, None, "USD", "2020-01-01T00:00:00+00:00"),
        )
    storage.record(make_observation("new"))
    deleted = storage.prune(30)
    assert deleted == 1
    assert storage.latest(730, "old") is None
    assert storage.latest(730, "new") is not None


@pytest.mark.parametrize("days", [0, -1, 366, True, "7", 1.5])
def test_prune_rejects_invalid_days(tmp_path, days):
    storage = Storage(tmp_path / "history.db")
    with pytest.raises(ValueError):
        storage.prune(days)


def test_watchlist_crud(tmp_path):
    storage = Storage(tmp_path / "history.db")
    item_id = storage.add_watch(
        "8181498258", 730, "AK-47 | Redline (Field-Tested)", "below", Decimal("25")
    )
    rows = storage.list_watch("8181498258")
    assert len(rows) == 1
    assert rows[0]["rule_value"] == "25"
    assert rows[0]["enabled"] is True

    assert storage.set_watch_value(item_id, "8181498258", Decimal("20")) is True
    assert storage.list_watch()[0]["rule_value"] == "20"

    assert storage.toggle_watch(item_id, "8181498258") is True
    assert storage.list_watch()[0]["enabled"] is False

    assert storage.delete_watch(item_id, "8181498258") is True
    assert storage.list_watch() == []


def test_watchlist_isolates_chats(tmp_path):
    storage = Storage(tmp_path / "history.db")
    storage.add_watch("1", 730, "X", "below", Decimal("5"))
    storage.add_watch("2", 730, "Y", "below", Decimal("6"))
    assert len(storage.list_watch("1")) == 1
    assert len(storage.list_watch("2")) == 1
    assert len(storage.list_watch()) == 2


@pytest.mark.parametrize(
    "kwargs",
    [
        {"chat_id": ""},
        {"appid": 0},
        {"market_hash_name": ""},
        {"rule_type": "bad"},
        {"rule_value": Decimal("-1")},
        {"interval_seconds": 1},
    ],
)
def test_add_watch_rejects_invalid(tmp_path, kwargs):
    storage = Storage(tmp_path / "history.db")
    params = {
        "chat_id": "1",
        "appid": 730,
        "market_hash_name": "X",
        "rule_type": "below",
        "rule_value": Decimal("5"),
        "interval_seconds": 300,
    }
    params.update(kwargs)
    with pytest.raises(ValueError):
        storage.add_watch(**params)
