from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest

from src.core import Observation
from src.storage import Storage


def make_observation(name="AK-47 | Redline (Field-Tested)", lowest="10.50"):
    return Observation(
        appid=730,
        market_hash_name=name,
        lowest=Decimal(lowest),
        median=Decimal("11.00"),
        volume=123,
        currency="USD",
        observed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )


def test_record_and_latest(tmp_path):
    storage = Storage(tmp_path / "history.db")
    assert storage.latest(730, "X' OR 1=1 --") is None
    observation = make_observation("X' OR 1=1 --")
    storage.record(observation)
    loaded = storage.latest(730, "X' OR 1=1 --")
    assert loaded is not None
    assert loaded.lowest == Decimal("10.50")
    assert loaded.median == Decimal("11.00")
    assert loaded.volume == 123


def test_latest_returns_newest(tmp_path):
    storage = Storage(tmp_path / "history.db")
    first = make_observation(lowest="20")
    storage.record(first)
    second = Observation(
        appid=730,
        market_hash_name=first.market_hash_name,
        lowest=Decimal("19"),
        median=None,
        volume=None,
        currency="USD",
        observed_at=(datetime.now(timezone.utc) + timedelta(seconds=1)).isoformat(timespec="seconds"),
    )
    storage.record(second)
    loaded = storage.latest(730, first.market_hash_name)
    assert loaded is not None
    assert loaded.lowest == Decimal("19")
    assert loaded.median is None
    assert loaded.volume is None


def test_prune(tmp_path):
    storage = Storage(tmp_path / "history.db")
    connection = storage._connect()
    with connection as db:
        db.execute(
            "INSERT INTO observations VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            ("old", 730, "old", "1", None, None, "USD", "2020-01-01T00:00:00+00:00"),
        )
    storage.record(make_observation("new"))
    deleted = storage.prune(30)
    assert deleted == 1
    assert storage.latest(730, "old") is None
    assert storage.latest(730, "new") is not None


@pytest.mark.parametrize("days", [0, -1, 366, True, "7", 1.5])
def test_prune_rejects_invalid_days(tmp_path, days):
    storage = Storage(tmp_path / "history.db")
    with pytest.raises(ValueError):
        storage.prune(days)
