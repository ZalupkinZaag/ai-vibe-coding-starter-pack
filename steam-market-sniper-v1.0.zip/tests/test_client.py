import asyncio
from decimal import Decimal

import httpx
import pytest

from src.client import SteamClient, SteamError

SETTINGS = {
    "country": "US",
    "currency": "USD",
    "currency_id": 1,
    "timeout_seconds": 1,
}


def run(coro):
    return asyncio.run(coro)


def client_with(handler):
    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return SteamClient(SETTINGS, http), http


def test_fetch_valid():
    def handler(request):
        assert "priceoverview" in str(request.url)
        assert request.url.params["appid"] == "730"
        return httpx.Response(
            200,
            json={"success": True, "lowest_price": "$9.99", "median_price": "$10.00", "volume": "1,000"},
        )

    client, http = client_with(handler)
    try:
        observation = run(client.fetch(730, "X"))
        assert observation.lowest == Decimal("9.99")
        assert observation.volume == 1000
    finally:
        run(http.aclose())


def test_fetch_html_response():
    client, http = client_with(lambda request: httpx.Response(200, text="<html>nope</html>"))
    try:
        with pytest.raises(SteamError, match="HTML"):
            run(client.fetch(730, "X"))
    finally:
        run(http.aclose())


def test_fetch_invalid_payload():
    client, http = client_with(lambda request: httpx.Response(200, json={"success": True}))
    try:
        with pytest.raises(SteamError, match="validation"):
            run(client.fetch(730, "X"))
    finally:
        run(http.aclose())


def test_fetch_404_is_not_retried():
    calls = []

    def handler(request):
        calls.append(1)
        return httpx.Response(404)

    client, http = client_with(handler)
    try:
        with pytest.raises(SteamError, match="HTTP 404"):
            run(client.fetch(730, "X"))
        assert len(calls) == 1
    finally:
        run(http.aclose())


def test_fetch_429_then_success():
    calls = []

    def handler(request):
        calls.append(1)
        if len(calls) == 1:
            return httpx.Response(429)
        return httpx.Response(
            200, json={"success": True, "lowest_price": "$1.00", "volume": "1"}
        )

    client, http = client_with(handler)
    try:
        observation = run(client.fetch(730, "X"))
        assert observation.lowest == Decimal("1.00")
        assert len(calls) == 2
    finally:
        run(http.aclose())


def test_fetch_oversized_response():
    client, http = client_with(lambda request: httpx.Response(200, text="x" * 100_001))
    try:
        with pytest.raises(SteamError, match="too large"):
            run(client.fetch(730, "X"))
    finally:
        run(http.aclose())
