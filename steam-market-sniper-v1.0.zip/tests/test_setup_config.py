import json
import os

import pytest

from src.envfile import load_env
from src.setup_config import validate_values, write_config

VALID = {
    "token": "123456789:AAFpKD0aI6eowIXHMsmvRKZvV-_-htKCE10",
    "chat_id": "8181498258",
    "appid": "730",
    "market_hash_name": "AK-47 | Redline (Field-Tested)",
    "rule_type": "below",
    "threshold": "25",
    "country": "US",
    "currency": "USD",
    "currency_id": "1",
    "delay": "1.5",
    "cooldown": "3600",
}


def test_validate_values():
    config = validate_values(VALID)
    assert config["telegram"]["chat_id"] == "8181498258"
    assert config["watch"][0]["rules"][0]["value"] == 25.0
    assert config["_token"] == VALID["token"]


@pytest.mark.parametrize(
    "field, value",
    [
        ("token", "bad"),
        ("chat_id", "abc"),
        ("appid", "0"),
        ("threshold", "-5"),
        ("delay", "0"),
        ("cooldown", "999999"),
        ("market_hash_name", ""),
        ("rule_type", "unknown"),
        ("currency_id", "abc"),
    ],
)
def test_validate_values_rejects_invalid(field, value):
    values = dict(VALID)
    values[field] = value
    with pytest.raises(ValueError):
        validate_values(values)


def test_write_config(tmp_path):
    files = write_config(tmp_path, VALID)
    assert files == ["config.json", "config.actions.json", ".env"]
    config = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))
    assert "_token" not in config
    assert config["telegram"]["chat_id"] == "8181498258"
    actions = json.loads((tmp_path / "config.actions.json").read_text(encoding="utf-8"))
    assert actions == config
    env = (tmp_path / ".env").read_text(encoding="utf-8")
    assert env.strip() == f"TELEGRAM_BOT_TOKEN={VALID['token']}"


def test_load_env(tmp_path, monkeypatch):
    monkeypatch.delenv("SNIPER_TEST_KEY", raising=False)
    (tmp_path / ".env").write_text(
        "# comment\nSNIPER_TEST_KEY=value\nBROKEN_LINE\n", encoding="utf-8"
    )
    load_env(tmp_path / ".env")
    assert os.environ["SNIPER_TEST_KEY"] == "value"
