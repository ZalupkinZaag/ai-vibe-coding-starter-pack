from src.bot import item_keyboard, main_keyboard, results_keyboard


def test_main_keyboard():
    keyboard = main_keyboard()
    callbacks = [button.callback_data for row in keyboard.inline_keyboard for button in row]
    assert callbacks == ["search", "my", "help"]


def test_results_keyboard():
    items = [
        {"name": "AK-47 | Redline", "price_text": "$29.30"},
        {"name": "AK-47 | Redline BT", "price_text": "$25.02"},
    ]
    keyboard = results_keyboard(items)
    callbacks = [button.callback_data for row in keyboard.inline_keyboard for button in row]
    assert callbacks == ["add:0", "add:1", "menu"]


def test_item_keyboard():
    keyboard = item_keyboard({"id": 7})
    callbacks = [button.callback_data for row in keyboard.inline_keyboard for button in row]
    assert callbacks == ["th:7", "tog:7", "del:7"]
