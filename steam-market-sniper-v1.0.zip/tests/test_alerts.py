import asyncio

import httpx
import pytest

from src.alerts import send_alert


def run(coro):
    return asyncio.run(coro)


def test_send_alert_success():
    def handler(request):
        return httpx.Response(200, json={"ok": True, "result": {"message_id": 1}})

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            await send_alert(http, "123:ABC", "42", "hello")

    run(scenario())


@pytest.mark.parametrize(
    "response",
    [
        httpx.Response(400),
        httpx.Response(200, json={"ok": False}),
        httpx.Response(200, text="not json"),
    ],
)
def test_send_alert_rejects_bad_response(response):
    def handler(request):
        return response

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            await send_alert(http, "123:ABC", "42", "hello")

    with pytest.raises(RuntimeError):
        run(scenario())


def test_send_alert_retries_network_error_once():
    calls = []

    def handler(request):
        calls.append(1)
        if len(calls) == 1:
            raise httpx.ConnectError("down")
        return httpx.Response(200, json={"ok": True})

    async def scenario():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http:
            await send_alert(http, "123:ABC", "42", "hello")

    run(scenario())
    assert len(calls) == 2
