# Telegram bot starter на aiogram 3

Минимальный бот: отвечает на `/start` и повторяет текстовые сообщения.

## Запуск

```bash
python -m pip install -r requirements.txt
copy .env.example .env
```

Заполни `BOT_TOKEN` в `.env` токеном от BotFather, затем:

```powershell
$env:BOT_TOKEN = (Get-Content .env | Select-String '^BOT_TOKEN=').Line.Split('=',2)[1]
python bot.py
```

Либо задай переменную окружения любым другим способом — бот читает `os.environ["BOT_TOKEN"]`.

## Структура

- `bot.py` — обработчики и точка входа.
- `.env.example` — шаблон переменных окружения.
- `requirements.txt` — зависимость aiogram 3.

Токен не хранится в коде. Не публикуй `.env` и не передавай токен покупателям или третьим сервисам.
