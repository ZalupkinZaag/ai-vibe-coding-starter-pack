# Telegram Bot Starter (aiogram 3)

Минимальный, но уже со структурой.

## Структура

```
bot.py              # точка входа
config.py           # настройки через pydantic-settings
handlers/
  start.py
  echo.py
.env.example
```

## Быстрый старт

1. Создай бота у @BotFather и получи токен.
2. Скопируй `.env.example` → `.env` и вставь токен.
3. Установи зависимости:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

4. Запусти:

```bash
python bot.py
```

## Что уже есть

- `/start`
- Echo любых текстовых сообщений
- Конфиг через pydantic-settings + `.env`
- Разделение на handlers

Дальше можно спокойно добавлять новые роутеры в `handlers/`.
