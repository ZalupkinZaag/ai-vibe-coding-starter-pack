import asyncio
import os

from aiogram import Bot, Dispatcher, F
from aiogram.types import Message

dp = Dispatcher()


@dp.message(F.text == "/start")
async def cmd_start(message: Message) -> None:
    await message.answer("Привет! Бот запущен.")


@dp.message()
async def echo(message: Message) -> None:
    if message.text:
        await message.answer(message.text)


async def main() -> None:
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN is not set. Copy .env.example to .env or export it.")
    bot = Bot(token=token)
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
