from aiogram import Router

from . import start, echo

router = Router()
router.include_router(start.router)
router.include_router(echo.router)
