from aiogram import Router, F
from aiogram.types import Message

router = Router()


@router.message(F.text)
async def echo_text(message: Message) -> None:
    if message.text:
        await message.answer(message.text)
