from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    await message.answer(
        "Привет. Бот запущен.\n"
        "Просто напиши что-нибудь — я отвечу тем же."
    )
