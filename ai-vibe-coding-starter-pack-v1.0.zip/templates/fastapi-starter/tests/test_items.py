from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_create_and_get_item():
    payload = {"name": "Test item", "price": 9.99}
    create_resp = client.post("/items", json=payload)
    assert create_resp.status_code == 201
    created = create_resp.json()
    assert created["name"] == payload["name"]
    assert created["price"] == payload["price"]
    assert "id" in created

    get_resp = client.get(f"/items/{created['id']}")
    assert get_resp.status_code == 200
    assert get_resp.json() == created


def test_get_missing_item():
    response = client.get("/items/999999")
    assert response.status_code == 404


def test_create_invalid_item():
    response = client.post("/items", json={"name": "", "price": -1})
    assert response.status_code == 422
