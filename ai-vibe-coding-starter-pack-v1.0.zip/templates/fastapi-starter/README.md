# FastAPI starter

Минимальный рабочий проект: эндпоинт проверки состояния, тест и настройки линтера.

## Запуск

```bash
python -m pip install -e ".[dev]"
python -m uvicorn app.main:app --reload
```

Проверка: открой `http://127.0.0.1:8000/health` — должно быть `{"status":"ok"}`.

## Тесты и линтер

```bash
python -m pytest -q
python -m ruff check .
```

## Структура

- `app/main.py` — приложение и эндпоинт `/health`.
- `tests/test_main.py` — тест эндпоинта.
- `pyproject.toml` — зависимости, тесты и настройки ruff.

Добавление новых маршрутов делай в `app/main.py`, тесты — в `tests/`.
