# FastAPI Starter

Минимальный, но уже структурированный стартер.

## Структура

```
app/
  api/          # роутеры
  core/         # конфиг
  main.py       # точка входа
tests/
```

## Быстрый старт

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"

uvicorn app.main:app --reload
```

Открой http://127.0.0.1:8000/docs

## Тесты и линтер

```bash
pytest -q
ruff check .
```

## Переменные окружения

Можно создать `.env`:

```
APP_NAME=My API
APP_VERSION=0.1.0
DEBUG=false
```

## Что уже есть

- `/health` — liveness
- `POST /items` + `GET /items/{id}` — простой пример с pydantic-валидацией
- pydantic-settings
- lifespan
- pytest + httpx
- ruff

In-memory store только для демонстрации. Для реального проекта замени на БД.
