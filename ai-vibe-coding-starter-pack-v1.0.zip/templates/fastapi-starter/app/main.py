from fastapi import FastAPI

app = FastAPI(title="Starter API", version="1.0.0")


@app.get("/health")
def health() -> dict[str, str]:
    """Liveness probe. Returns a fixed status, no external dependencies."""
    return {"status": "ok"}
