from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api import health, items
from app.core.config import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    yield
    # shutdown


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        lifespan=lifespan,
    )
    app.include_router(health.router)
    app.include_router(items.router)
    return app


app = create_app()
