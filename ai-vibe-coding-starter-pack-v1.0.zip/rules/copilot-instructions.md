# Project instructions

Applies to the whole repository. Keep changes small, verifiable and consistent with the existing code.

## Environment

- Python 3.11+ for backend code; TypeScript for frontend code when present.
- Tests: pytest. Linter and formatter: ruff. No wildcard imports.
- Configuration comes from environment variables or explicit config files. Never hardcode secrets, tokens or endpoints.

## Code rules

1. Read the surrounding files before editing. Match existing naming, structure and style.
2. Never invent a value you did not see: offsets, URLs, API keys, enum members, field names, default ports. If a value is unknown, say so and give the shortest way to find it.
3. Put pure logic in functions that can be tested without external services. Keep I/O at the boundaries.
4. Validate data at real boundaries: files, network responses, user input, external processes. Treat partial reads as failures.
5. Bound every loop and every count that comes from external data.
6. Comments only for constraints the code cannot express. Provenance of magic values belongs in a config, not in a comment.
7. Do not leave TODO stubs in delivered code. An unimplemented part must be visibly marked and gated.
8. Prefer explicit standard-library and third-party imports at the top of the file.
9. Use RAII for handles, connections and resources; release them on both success and failure paths.
10. When you change behavior, add or update a test that would fail without the change.

## Response format

After a task, report in four short parts:

1. Files changed.
2. Commands run with their exit codes, or "not run" with the reason.
3. Checks performed and their results.
4. What was not verified and the shortest next verification step.

A successful build is not proof of correct behavior. Do not claim a feature works until it was observed running.
