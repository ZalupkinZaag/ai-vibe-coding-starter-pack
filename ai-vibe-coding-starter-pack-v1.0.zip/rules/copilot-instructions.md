# Project Instructions for GitHub Copilot

## Core rules

- Match the existing style of the files you edit. Do not reformat unrelated code.
- Read before you write. If a symbol is unknown — search for its definition first.
- Never invent configuration values, endpoints, tokens, type names, field names or versions. If something is unknown — say so and suggest how to verify it.
- Prefer the smallest change that solves the task.
- Pure logic lives in pure functions. Network, filesystem and processes stay at the edges.
- Validate all external input. Bound loops and collection sizes. Treat partial/invalid data as failure.
- No TODO, FIXME or stub implementations in delivered code. Unfinished parts must be explicitly gated or removed.
- When behavior changes — add or update tests.
- Always report: which files changed, which commands were run (with exit codes), what was verified and what was not.

## Workflow

1. State a short plan before editing more than one file.
2. Make the minimal set of changes.
3. Run the project's existing test / lint / build commands.
4. Fix real errors, do not suppress them.
5. Summarize what was done and what remains unverified.

## Style

- Prefer explicit over clever.
- Prefer early returns over deep nesting.
- Prefer concrete types over `Any` / untyped dicts.
- Comments only when the "why" is non-obvious.
