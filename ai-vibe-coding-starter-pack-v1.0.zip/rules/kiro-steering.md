# Kiro Steering Rules

Place in `.kiro/steering/rules.md` with appropriate frontmatter (`inclusion: always` or fileMatch).

## Rules

- Never invent unknown values (config, endpoints, types, field names, versions).
- Prefer minimal diffs. Change only what is required.
- Match existing code style. Do not drive-by reformat.
- Pure functions for logic. Side effects only at boundaries.
- Validate all external input. Fail fast on invalid data.
- No stubs or TODOs in the final diff.
- When changing behavior — update or add tests.
- Always report real commands that were run and their results.

## Preferred workflow

1. Plan briefly.
2. Change minimally.
3. Run existing project commands.
4. Report honestly what was verified.
