# Kiro steering rules

Copy to `.kiro/steering/rules.md`. The frontmatter below is the common `inclusion` form; verify the field names in your Kiro version.

```yaml
---
inclusion: always
---
```

## Always apply

- Work in small, reviewable steps. Do not rewrite whole files when a targeted edit gives the same result.
- Follow the structure, naming and dependencies already present in the repository.
- Never fabricate values from a build, protocol or API: addresses, IDs, tokens, enum values, schemas. Mark them unknown and describe the shortest verification.
- Keep business logic free of I/O so it can be checked without the external system.
- Validate data crossing a boundary: files, sockets, subprocess output, user input. Bound all externally supplied counts.
- Use explicit imports and standard-library tools where possible.
- Finish the whole task. Do not end with a plan or an offer to continue while work remains.
- Report files changed, exact commands with exit codes, checks run, and anything not verified.
