# Windsurf rules

Use this file with Windsurf. Copy it to `.windsurfrules` (older versions) or to `.windsurf/rules/project.md` with the frontmatter shown below (newer versions). Confirm the exact format in your Windsurf version — it changed between releases.

```yaml
---
description: Project-wide coding conventions
globs: *
alwaysApply: true
---
```

## Conventions

- Match the style of the files you are editing. Do not reformat unrelated code.
- Read before you write. If a symbol is unfamiliar, search for its definition first.
- Do not invent configuration values, endpoints, tokens, constants or type names. Unknown means unknown; state how to verify it.
- Pure logic lives in testable functions. Network, files and processes stay at the edges.
- Validate external data, bound loops and counts, and treat partial input as failure.
- No TODO stubs in delivered code. Mark unfinished areas explicitly and keep them gated.
- Add or update tests whenever behavior changes.
- Report commands with exit codes and separate what was run from what was only assumed.

## Workflow

1. State the plan in one short paragraph before editing multiple files.
2. Make the smallest set of changes that solves the task.
3. Run the project's existing build and test commands; read real errors, fix the cause, rerun.
4. Summarize files changed, verification performed and what remains unverified.
