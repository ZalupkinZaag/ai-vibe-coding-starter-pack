# Windsurf Rules

Copy to `.windsurfrules` (older) or `.windsurf/rules/project.md` (newer) with frontmatter:

```yaml
---
description: Project-wide coding conventions and anti-slop rules
globs: "*"
alwaysApply: true
---
```

## Conventions

- Match the style of the files you are editing. Do not reformat unrelated code.
- Read before you write. Search for definitions of unknown symbols.
- Do not invent configuration values, endpoints, tokens, constants, type names or field names. Unknown = unknown. State how to verify.
- Pure logic in testable functions. I/O (network, files, processes) stays at the edges.
- Validate external data. Bound loops and counts. Partial input = failure.
- No TODO / stub code in delivered changes. Mark unfinished areas explicitly and gate them.
- Add or update tests when behavior changes.
- Report commands with exit codes. Separate what was actually run from what was only assumed.

## Workflow

1. State the plan in one short paragraph before multi-file edits.
2. Make the smallest set of changes that solves the task.
3. Run the project's existing build and test commands. Read real errors. Fix the cause, not the symptom.
4. Summarize: files changed, verification performed, what remains unverified.

## Anti-patterns (forbidden)

- Inventing API fields or response shapes.
- Adding "just in case" abstraction layers.
- Changing public interfaces without necessity.
- Leaving dead code or commented-out blocks.
- Writing tests that always pass or test nothing real.
