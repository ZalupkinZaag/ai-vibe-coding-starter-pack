# AI Vibe Coding Starter Pack — v1.0

Готовый набор правил, промптов и шаблонов для работы с AI-кодингом в Windsurf, GitHub Copilot, Kiro и Cursor.

Версия: 1.0
Дата сборки: 2026-11-22
Совместимость: Windsurf, GitHub Copilot (VS Code), Kiro, Cursor. Точные имена файлов правил зависят от версии инструмента — см. таблицу ниже.

## Состав

| Путь | Что это |
|---|---|
| `rules/copilot-instructions.md` | Правила проекта для GitHub Copilot. Копируется в `.github/copilot-instructions.md`. |
| `rules/windsurf-rules.md` | Правила для Windsurf. Копируется в `.windsurfrules` или `.windsurf/rules/<name>.md`. |
| `rules/kiro-steering.md` | Steering-правила для Kiro. Копируется в `.kiro/steering/rules.md`. |
| `prompts/dev-prompts.md` | 20 готовых промптов на типовые задачи разработки. |
| `guides/mcp-setup.md` | Что такое MCP и как подключить сервер к редактору; рабочий пример на Python. |
| `guides/agent-workflow.md` | Цикл Plan → Code → Test → Review с чек-листами. |
| `cheatsheet/commands.md` | Памятка по командам и промпт-паттернам. |
| `templates/fastapi-starter/` | Минимальный FastAPI-проект с тестами и конфигурацией линтера. |
| `templates/telegram-bot-starter/` | Минимальный бот на aiogram 3 с `/start` и `.env.example`. |

## Куда класть файлы правил

| Инструмент | Путь | Примечание |
|---|---|---|
| GitHub Copilot | `.github/copilot-instructions.md` | Стандартный путь для инструкций репозитория. |
| Windsurf (старые версии) | `.windsurfrules` | Один файл в корне проекта. |
| Windsurf (новые версии) | `.windsurf/rules/*.md` | Файл с frontmatter `description`, `globs`, `alwaysApply`. |
| Kiro | `.kiro/steering/*.md` | Frontmatter `inclusion: always` / `fileMatch`. |
| Cursor | `.cursor/rules/*.mdc` или `.cursorrules` | Зависит от версии. |

Если инструмент не подхватил правила, проверь его версию и попробуй альтернативный путь из таблицы.

## Как использовать

1. Скопируй нужный файл правил в корень своего проекта по пути из таблицы.
2. Открой проект в редакторе и убедись, что правила подхвачены: попроси агента описать Convention проекта.
3. Бери промпты из `prompts/dev-prompts.md` и заменяй значения в скобках под свою задачу.
4. Для быстрого старта скопируй один из шаблонов и выполни шаги из его README.

## Ограничения

Набор содержит текст и шаблоны кода. Он не даёт подписок, API-ключей и доступа к платным моделям. Работоспособность конкретного шаблона проверена на уровне синтаксиса Python; установка зависимостей и запуск в твоём окружении остаются за тобой.
